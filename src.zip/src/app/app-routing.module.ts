import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {
    path: '',
    redirectTo: 'ng-switch',
    pathMatch: 'full'
  },
  {
    path: 'ng-switch',
    loadChildren: () => import('./views/switch-case/switch-case.module').then(m => m.SwitchCaseModule)
  },
  {
    path: 'component-factory',
    loadChildren: () => import('./views/component-factory/component-factory.module').then(m => m.ComponentFactoryModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
